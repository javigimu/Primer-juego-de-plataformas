using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemigo : MonoBehaviour
{
    [SerializeField] List<Transform> waypoints;
    float velocidad = 1.5f;
    float distaciaDeCambio = 0.2f;
    byte siguientePosicion = 0;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        transform.position = Vector3.MoveTowards(
            transform.position,
            waypoints[siguientePosicion].transform.position,
            velocidad * Time.deltaTime);

        if (Vector3.Distance(transform.position, 
            waypoints[siguientePosicion].transform.position) 
            < distaciaDeCambio)
        {
            siguientePosicion++;
            if (siguientePosicion >= waypoints.Count)
            {
                siguientePosicion = 0;
            }
        }
    }

    public void OnTriggerEnter2D(Collider2D other)
    {        
        if (other.gameObject.tag == "Player")
        {
            FindObjectOfType<GameController>().SendMessage("PerderVida");
        }
    }
}
