using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameStatus : MonoBehaviour
{
    private int puntos = 0;
    private int vidas = 3;
    private int nivelActual = 1;
    [SerializeField] public int nivelMaximo;

    public int GetPuntos() { return puntos; }
    public int GetVidas() { return vidas; }
    public int GetNivelActual() { return nivelActual; }
    public void SetPuntos(int puntos) { this.puntos = puntos; }
    public void SetVidas(int vidas) { this.vidas = vidas; }
    public void SetNivelActual(int nivelActual) { this.nivelActual = nivelActual; }

    // Start before Start function
    private void Awake()
    {
        int gameStatusCount = FindObjectsOfType<GameStatus>().Length;
        if ( gameStatusCount > 1)
        {
            Destroy(gameObject);
        }
        else
        {            
            DontDestroyOnLoad(gameObject);
        }
    }

    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
