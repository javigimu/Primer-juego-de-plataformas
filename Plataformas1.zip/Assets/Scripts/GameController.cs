using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameController : MonoBehaviour
{
    private int puntos;
    private int vidas;
    private int itemsRestantes;
    private int nivelActual;
    [SerializeField] UnityEngine.UI.Text textoGameOver;
    [SerializeField] UnityEngine.UI.Text textoPuntos;

    // Start is called before the first frame update
    void Start()
    {
        puntos = FindObjectOfType<GameStatus>().GetPuntos();
        vidas = FindObjectOfType<GameStatus>().GetVidas();
        nivelActual = FindObjectOfType<GameStatus>().GetNivelActual();
        itemsRestantes = FindObjectsOfType<Diamante>().Length;
        textoGameOver.enabled = false;
        textoPuntos.enabled = false;        
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.N))
        {
            AvanzarNivel();
        }
    }

    public void SumarPuntos(int cantidad)
    {
        puntos += cantidad;
        FindObjectOfType<GameStatus>().SetPuntos(puntos);
    }

    public void AnotarItemRecogido(int cantidad)
    {
        SumarPuntos(cantidad);
        itemsRestantes--;                
        if (itemsRestantes <= 0)
        {
            AvanzarNivel();
        }
        Debug.Log("Puntos: " + puntos);
        Debug.Log("Items restantes: " + itemsRestantes);
    }

    public void PerderVida()
    {
        vidas--;
        FindObjectOfType<GameStatus>().SetVidas(vidas);
        FindObjectOfType<Player>().SendMessage("Recolocar");        
        Debug.Log("Vidas: " + vidas);
        if (vidas <= 0)
        {
            // Lanzar una corrutina
            StartCoroutine(TerminarPartida());
        }
    }

    // Devuelve un IEnumerator y en yield return creamos una espera de 3 seg
    private IEnumerator TerminarPartida()
    {
        textoPuntos.text = puntos + " puntos";
        textoPuntos.enabled = true;
        textoGameOver.enabled = true;
        Time.timeScale = 0.1f;
        yield return new WaitForSecondsRealtime(3);
        Time.timeScale = 1;
        ResetearStatus();
        SceneManager.LoadScene("Menu");
    }

    public void ResetearStatus()
    {
        puntos = 0;
        vidas = 3;
        nivelActual = 1;
        FindObjectOfType<GameStatus>().SetPuntos(puntos);
        FindObjectOfType<GameStatus>().SetVidas(vidas);
        FindObjectOfType<GameStatus>().SetNivelActual(nivelActual);
    }

    public void AvanzarNivel()
    {       
        nivelActual++;
        if (nivelActual > FindObjectOfType<GameStatus>().nivelMaximo)
            nivelActual = 1;
        FindObjectOfType<GameStatus>().SetNivelActual(nivelActual);
        SceneManager.LoadScene("Nivel" + nivelActual);        
    }
}
